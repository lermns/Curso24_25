import javax.swing.*;

public class Actividad3 {
    private JButton button1;
    private JCheckBox checkBox1CheckBox;
    private JCheckBox checkBox2CheckBox;
    private JRadioButton radioButton1RadioButton;
    private JRadioButton radioButton2RadioButton;
    private JButton button2;
    private JComboBox comboBox1;
    private JSpinner spinner1;
    private JSlider slider1;
    private JProgressBar progressBar1;
}
