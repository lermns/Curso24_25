package cajatextoautovalidante;


import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

public class CampoTextoConError extends JPanel {
    private JTextField textField;
    private JLabel errorLabel;
    private String tipoDato;

    public CampoTextoConError(String labelText, String tipoDato) {
        this.tipoDato = tipoDato;
        setLayout(new BorderLayout());

        // Etiqueta
        JLabel label = new JLabel(labelText);
        add(label, BorderLayout.NORTH);

        // Caja de texto
        textField = new JTextField();
        textField.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                // Limpiar error al enfocar el campo
                clearError();
            }

            @Override
            public void focusLost(FocusEvent e) {
                // Validar al perder el foco
                validarFormato();
            }
        });
        add(textField, BorderLayout.CENTER);

        // Etiqueta de error (inicialmente invisible)
        errorLabel = new JLabel("Campo obligatorio");
        errorLabel.setForeground(Color.RED);
        errorLabel.setVisible(false);
        add(errorLabel, BorderLayout.SOUTH);
    }

    public String getText() {
        return textField.getText();
    }

    public void setError(String errorMessage) {
        errorLabel.setText(errorMessage);
        errorLabel.setVisible(true);
    }

    public void clearError() {
        errorLabel.setText("");
        errorLabel.setVisible(false);
    }

    private void validarFormato() {
        String texto = textField.getText();
        clearError();

        // Realizar validación de formato según el tipoDato
        switch (tipoDato) {
            case "DNI":
                if (!texto.matches("\\d{8}[A-HJ-NP-TV-Z]")) {
                    setError("Formato de DNI incorrecto");
                }
                break;
            case "CP":
                if (!texto.matches("\\d{5}")) {
                    setError("Formato de código postal incorrecto");
                }
                break;
            case "Telefono":
                if (!texto.matches("\\d{9}")) {
                    setError("Formato de teléfono incorrecto");
                }
                break;
            // Puedes agregar más casos según sea necesario
        }
    }
}
