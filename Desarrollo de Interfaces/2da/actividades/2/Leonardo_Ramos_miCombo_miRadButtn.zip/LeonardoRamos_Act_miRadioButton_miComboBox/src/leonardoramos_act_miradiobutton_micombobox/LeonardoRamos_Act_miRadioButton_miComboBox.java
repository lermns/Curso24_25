package leonardoramos_act_miradiobutton_micombobox;

public class LeonardoRamos_Act_miRadioButton_miComboBox {
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new MiComboBoxMiRadioButton().setVisible(true);
        });    }   
}
