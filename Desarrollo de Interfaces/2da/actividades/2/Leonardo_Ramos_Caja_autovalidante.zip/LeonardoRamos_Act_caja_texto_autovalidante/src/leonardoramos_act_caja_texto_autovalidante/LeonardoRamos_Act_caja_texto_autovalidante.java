/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package leonardoramos_act_caja_texto_autovalidante;

/**
 *
 * @author Usuario
 */
public class LeonardoRamos_Act_caja_texto_autovalidante {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            new CajaTexto().setVisible(true);
        });    }
    
}
