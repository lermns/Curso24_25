package leonardoramos_act_caja_texto_autovalidante;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

public class CajaDeTextoAutovalidante extends JPanel {
    private JTextField texto;         // Campo de texto
    private JLabel mensajeError;      // Mensaje de error
    private String tipoValidacion;    // Tipo de validación

    public CajaDeTextoAutovalidante(String tipoValidacion) {
        this.tipoValidacion = tipoValidacion;
        initComponent();
    }
    
    public CajaDeTextoAutovalidante() {
        super();
    }

    private void initComponent() {
        setLayout(new BorderLayout());

        // Campo de texto y etiqueta de error
        texto = new JTextField(15);
        mensajeError = new JLabel(" "); // Espacio inicial para que no desajuste el layout
        mensajeError.setForeground(Color.RED);

        // Agregar validación al perder el foco
        texto.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                mensajeError.setText(" "); // Limpiar mensaje de error
            }

            @Override
            public void focusLost(FocusEvent e) {
                validarTexto();
            }
        });

        // Añadir los componentes al panel
        add(texto, BorderLayout.NORTH);
        add(mensajeError, BorderLayout.SOUTH);
    }

    private void validarTexto() {
        String textoIngresado = texto.getText();
        String error = " ";

        error = switch (tipoValidacion.toUpperCase()) {
            case "DNI" -> validarDNI(textoIngresado);
            case "TFN" -> validarTFN(textoIngresado);
            case "CP" -> validarCP(textoIngresado);
            default -> "Tipo de validación desconocido.";
        };

        mensajeError.setText(error); // Mostrar mensaje de error
    }

    private String validarDNI(String texto) {
        if (texto.length() != 9) {
            return "El DNI debe tener 9 caracteres.";
        }

        try {
            Integer.valueOf(texto.substring(0, 8)); // Validar los primeros 8 caracteres como números
        } catch (NumberFormatException e) {
            return "Los 8 primeros caracteres del DNI deben ser números.";
        }

        char letra = texto.charAt(8);
        if (!Character.isLetter(letra)) {
            return "El último carácter del DNI debe ser una letra.";
        }

        return "Sin errores.";
    }

    private String validarTFN(String texto) {
        if (texto.length() != 9) {
            return "El teléfono debe tener 9 dígitos.";
        }

        try {
            Integer.valueOf(texto);
        } catch (NumberFormatException e) {
            return "El teléfono solo debe contener números.";
        }

        return "Sin errores.";
    }

    private String validarCP(String texto) {
        if (texto.length() != 5) {
            return "El código postal debe tener 5 dígitos.";
        }

        try {
            Integer.valueOf(texto);
        } catch (NumberFormatException e) {
            return "El código postal solo debe contener números.";
        }

        return "Sin errores.";
    }

    public String getTexto() {
        return texto.getText();
    }

    public void setTipoValidacion(String tipoValidacion) {
        this.tipoValidacion = tipoValidacion;
    }
}
