/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package leonardoramos_act_caja_texto_autovalidante;

import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.BorderFactory;
import javax.swing.JLabel;

public class CajaTexto extends javax.swing.JFrame {

    private CajaDeTextoAutovalidante cajaDNI;
    private CajaDeTextoAutovalidante cajaTFN;
    private CajaDeTextoAutovalidante cajaCP;

    public CajaTexto() {
        initComponents(); // Inicializa el diseño básico generado por NetBeans
        agregarComponentesManualmente(); // Método adicional para agregar componentes
    }

    private void agregarComponentesManualmente() {
        
        // Configuración manual del layout
        setLayout(new java.awt.GridLayout(6, 2, 1, 1)); // 6 filas, 1 columna, 5px de separación

        // Crear etiquetas descriptivas
        JLabel labelDNI = new JLabel("DNI:");
        JLabel labelTFN = new JLabel("Teléfono:");
        JLabel labelCP = new JLabel("Código Postal:");
        
        labelDNI.setPreferredSize(new Dimension(50, 30));
        labelTFN.setPreferredSize(new Dimension(50, 30));
        labelCP.setPreferredSize(new Dimension(50, 30));
        
        // Crear instancias de las cajas autovalidantes
        cajaDNI = new CajaDeTextoAutovalidante("DNI");
        cajaTFN = new CajaDeTextoAutovalidante("TFN");
        cajaCP = new CajaDeTextoAutovalidante("CP");
        
        // Agregar los componentes al JFrame
        add(labelDNI, BorderLayout.CENTER);
        add(cajaDNI, BorderLayout.CENTER);
        add(labelTFN, BorderLayout.CENTER);
        add(cajaTFN, BorderLayout.CENTER);
        add(labelCP, BorderLayout.CENTER);
        add(cajaCP, BorderLayout.CENTER);
        
        labelDNI.setBorder(BorderFactory.createEmptyBorder(10, 170, 1, 20));  // Márgenes: arriba, izquierda, abajo, derecha
        cajaDNI.setBorder(BorderFactory.createEmptyBorder(10, 170, 10, 220));  // Márgenes: arriba, izquierda, abajo, derecha

        labelTFN.setBorder(BorderFactory.createEmptyBorder(10, 170, 1, 20));
        cajaTFN.setBorder(BorderFactory.createEmptyBorder(10, 170, 10, 220));
        
        labelCP.setBorder(BorderFactory.createEmptyBorder(10, 170, 1, 20)); 
        cajaCP.setBorder(BorderFactory.createEmptyBorder(10, 170, 10, 220));


        // Ajustar tamaño y centrar la ventana
        pack();
        setLocationRelativeTo(null);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(800, 600));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
