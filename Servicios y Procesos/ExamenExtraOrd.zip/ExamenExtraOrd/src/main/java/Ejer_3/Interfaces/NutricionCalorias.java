package Ejer_3.Interfaces;

public interface NutricionCalorias {
    double CERDO = 500;
    double TERNERA = 800;
    double LUBINA = 400;
    double EMPERADOR = 300;
    double SUSHI = 100;

    double digerir();
}
