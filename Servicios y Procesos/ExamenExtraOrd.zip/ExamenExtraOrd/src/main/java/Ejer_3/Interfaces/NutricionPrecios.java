package Ejer_3.Interfaces;

public interface NutricionPrecios {
    double CERDO = 5.60;
    double TERNERA = 17.80;
    double LUBINA = 15.50;
    double EMPERADOR = 12.45;
    double SUSHI = 10;

    void masticar();
}
