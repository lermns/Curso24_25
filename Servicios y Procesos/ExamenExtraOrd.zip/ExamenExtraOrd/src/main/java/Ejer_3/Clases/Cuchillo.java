package Ejer_3.Clases;

public class Cuchillo{
    public void cortar(){
        System.out.println("\ncortó la comida");
    }

    @Override
    public String toString() {
        return "Cuchillo";
    }
}
