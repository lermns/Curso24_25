package Ejer_3.Clases;

public class Tenedor{
    public void pinchar(){
        System.out.println("pinchó la comida\n");
    }

    @Override
    public String toString() {
        return "Tenedor";
    }
}
